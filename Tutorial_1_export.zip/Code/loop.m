 for i=1:1:5
	disp(i)
 end
 x = 5;
 while x>2
 	 disp(x)
	x = x - 1;
 end

 x = 10;
 if x<10
     disp('Hello');
 else
     disp('Fine');
 end
