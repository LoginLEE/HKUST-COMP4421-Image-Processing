a = min(2,7);
b=[1 2 3];
c=[1 2 3;4 5 6];
whos %List all the variables in the workspace
