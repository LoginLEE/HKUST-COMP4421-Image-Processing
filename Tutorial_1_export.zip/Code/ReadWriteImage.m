g = imread('Venice.jpg');
figure,imshow(g);
sg=size(g);
f=rgb2gray(g);
sf=size(f);
imwrite(f, 'NewImageGray.jpg');
fg=imread( 'NewImageGray.jpg');
figure,imshow(fg);

