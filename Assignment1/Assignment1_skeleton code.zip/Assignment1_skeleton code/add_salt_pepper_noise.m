function noisy_image = add_salt_pepper_noise(img_input, p)



end

