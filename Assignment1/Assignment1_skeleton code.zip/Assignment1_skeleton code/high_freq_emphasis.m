function img_result = high_freq_emphasis(img_input, a, b)


end