function img_result = filter_spa(img_input, filter)


end