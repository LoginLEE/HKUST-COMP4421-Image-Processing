function noisy_image = add_gaussian_noise(img_input, g_mean, g_std)


end

