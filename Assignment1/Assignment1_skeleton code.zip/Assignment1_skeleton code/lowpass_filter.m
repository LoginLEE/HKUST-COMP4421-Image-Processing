function img_result = lowpass_filter(img_input,D0)


end

