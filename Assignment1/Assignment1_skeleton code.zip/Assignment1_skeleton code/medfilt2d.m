function img_result = medfilt2d(img_input, size)

end