1. Matlab
2. No
3. LEE Lok Yin (20450512)